package protocols;

public class GlobalConstants {

    public static final int GLOBAL_PORT = 3000;



}
